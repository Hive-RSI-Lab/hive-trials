//go:build acceptance

package wc

import (
	"reflect"
	"testing"
)

func TestCount(t *testing.T) {
	tests := []struct {
		name     string
		input    string
		expected map[string]int
	}{
		{
			name:     "empty input",
			input:    "",
			expected: map[string]int{},
		},
		{
			name:     "single word",
			input:    "hello",
			expected: map[string]int{"hello": 1},
		},
		{
			name:     "multiple words",
			input:    "hello world",
			expected: map[string]int{"hello": 1, "world": 1},
		},
		{
			name:     "case insensitive",
			input:    "Hello HELLO hello",
			expected: map[string]int{"hello": 3},
		},
		{
			name:     "with punctuation",
			input:    "hello, world!",
			expected: map[string]int{"hello": 1, "world": 1},
		},
		{
			name:     "mixed punctuation and case",
			input:    "Hello, WORLD! hello?",
			expected: map[string]int{"hello": 2, "world": 1},
		},
		{
			name:     "numbers and symbols ignored",
			input:    "hello123 world456",
			expected: map[string]int{"hello": 1, "world": 1},
		},
		{
			name:     "only punctuation",
			input:    "!!! ??? ...",
			expected: map[string]int{},
		},
		{
			name:     "unicode letters",
			input:    "Café, CAFÉ naïve",
			expected: map[string]int{"café": 2, "naïve": 1},
		},
		{
			name:     "apostrophes and hyphens split",
			input:    "Don't stop, well-known",
			expected: map[string]int{"don": 1, "t": 1, "stop": 1, "well": 1, "known": 1},
		},
		{
			name:     "digits and underscores split a word",
			input:    "abc123def snake_case",
			expected: map[string]int{"abc": 1, "def": 1, "snake": 1, "case": 1},
		},
		{
			name:     "tabs and newlines",
			input:    "one\ttwo\nthree\r\nOne",
			expected: map[string]int{"one": 2, "two": 1, "three": 1},
		},
		{
			name:     "non-letter runes split",
			input:    "hi😀there hi—there",
			expected: map[string]int{"hi": 2, "there": 2},
		},
		{
			name:     "non-latin letters",
			input:    "ПРИВЕТ привет 東京",
			expected: map[string]int{"привет": 2, "東京": 1},
		},
		{
			name:     "upper-case non-ascii letters",
			input:    "ÉCOLE école ÅNGSTRÖM",
			expected: map[string]int{"école": 2, "ångström": 1},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := Count(tt.input)
			if !reflect.DeepEqual(result, tt.expected) {
				t.Errorf("Count(%q) = %v, want %v", tt.input, result, tt.expected)
			}
		})
	}
}
