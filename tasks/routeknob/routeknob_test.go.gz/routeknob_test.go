//go:build acceptance

package routeknob

import "testing"

// step is one move of the knob to pos while the Hive holds cur, and what it
// should do: act, and say a prompt or not.
type step struct {
	pos, cur int
	act      bool
	prompt   bool
}

func run(t *testing.T, steps []step) {
	t.Helper()
	var k Knob
	for i, s := range steps {
		act, prompt := k.Move(s.pos, s.cur)
		if act != s.act || (prompt != "") != s.prompt {
			t.Fatalf("move %d: Move(%d, %d) = %v, %q; want act %v, prompt %v", i, s.pos, s.cur, act, prompt, s.act, s.prompt)
		}
	}
}

// The deck's fix (68c27a8): a route the knob has no stop for can't be picked
// up by passing it, so the knob acts on its first move, with no prompt.
func TestOffItsStopsActsAtOnce(t *testing.T) {
	run(t, []step{{3, -1, true, false}, {1, -1, true, false}, {4, -1, true, false}})
}

func TestOffItsStopsFromAnyFirstStop(t *testing.T) {
	for pos := 0; pos < 5; pos++ {
		run(t, []step{{pos, -1, true, false}})
	}
}

// The knob stays live: never dead after its first move off the stops.
func TestOffItsStopsAfterAPrompt(t *testing.T) {
	run(t, []step{
		{5, 2, false, true},
		{4, -1, true, false},
		{4, -1, true, false},
	})
}

// Acting off the stops is a pickup: the next time the knob has to be picked
// up, it says so again.
func TestPromptAgainAfterOffItsStops(t *testing.T) {
	run(t, []step{
		{5, 2, false, true},
		{4, -1, true, false},
		{6, 1, false, true},
		{7, 1, false, false},
		{1, 1, false, false},
		{2, 1, true, false},
	})
}

func TestBackOnAStop(t *testing.T) {
	run(t, []step{
		{3, -1, true, false},
		{3, 3, false, false},
		{4, 3, true, false},
		{0, 5, false, true},
		{1, 5, false, false},
		{2, -1, true, false},
	})
}

func TestPickupByReaching(t *testing.T) {
	run(t, []step{
		{5, 2, false, true},
		{3, 2, false, false},
		{2, 2, false, false},
		{3, 2, true, false},
		{2, 2, false, false},
	})
}

func TestPickupByCrossing(t *testing.T) {
	run(t, []step{{5, 2, false, true}, {0, 2, true, false}})
	run(t, []step{{0, 2, false, true}, {1, 2, false, false}, {4, 2, true, false}})
}

// The first move is no crossing: there is nowhere it came from.
func TestFirstMoveNeedsPickup(t *testing.T) {
	run(t, []step{{0, 2, false, true}})
	run(t, []step{{2, 2, false, false}, {3, 2, true, false}})
}

// A move that needs a pickup still counts as where the knob was.
func TestCrossingFromAPromptedStop(t *testing.T) {
	run(t, []step{{6, 3, false, true}, {5, 3, false, false}, {4, 3, false, false}, {1, 3, true, false}})
}

// The route the knob set comes back as the Hive's; a route changed elsewhere
// has to be picked up again.
func TestHiveChangesElsewhere(t *testing.T) {
	run(t, []step{
		{2, 2, false, false},
		{3, 2, true, false},
		{3, 3, false, false},
		{4, 3, true, false},
		{4, 4, false, false},
		{5, 1, false, true},
		{6, 1, false, false},
		{0, 1, true, false},
	})
}
